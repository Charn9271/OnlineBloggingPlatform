# Spring-Boot-Thymleaf-BlogsApp-MySQL-SpringMVC
Realtime Blogs Application with Springboot, Thymeleaf and MySQL.

<h2>Completed Below Functionalities</h2>

<li>Login </li>
<li>Signup</li>
<li>Home View</li>
<li>User Blog Dashboard</li>
<li>Post/Edit/Delete Blog</li>
<li>Post/Delete Comment</li>
<li>Comment List</li>
<li>Post List</li>
<li>Search with AJAX</li>
<li>Logout</li></li>

<br>

https://user-images.githubusercontent.com/47443012/236621238-4c208894-a247-49d6-ac3a-2568dcfc6286.mp4

