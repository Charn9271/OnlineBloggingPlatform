package com.ag.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ag.AppUtils;
import com.ag.model.BlogsDataResp;
import com.ag.model.LoginRequestModel;
import com.ag.service.BlogsServices;

@Controller
public class FormLoaderController {

	@Autowired
	BlogsServices blogsServices;
	
	@GetMapping("/")  // Define the URL path for the home page
    public String showHomePage() {
        return "home";  // This should match the name of your home.html template
    }
	
	@GetMapping(value="/admin")  // Define the URL path for the home page
    public String adminLogin() {
		return "admin";// This should match the name of your home.html template
    }
	@GetMapping(value="/game")  // Define the URL path for the home page
    public String Games() {
		return "game";// This should match the name of your home.html template
    }
	@GetMapping(value="/game1")  // Define the URL path for the home page
    public String GameOne() {
		return "game1";// This should match the name of your home.html template
    }
	@GetMapping(value="/game2")  // Define the URL path for the home page
    public String GameTwo() {
		return "game2";// This should match the name of your home.html template
    }
	@GetMapping(value="/game3")  // Define the URL path for the home page
    public String GameThree() {
		return "game3";// This should match the name of your home.html template
    }
	@GetMapping(value="/game4")  // Define the URL path for the home page
    public String GameFour() {
		return "game4";// This should match the name of your home.html template
    }
	
	@GetMapping("/user-all")  // Define the URL path for the home page
    public String userAll(){
        return "user-all";  // This should match the name of your home.html template
    }
	@GetMapping(value = "/all")
	public String index(Model model) {
		List<BlogsDataResp> allBlogs = blogsServices.getAllBlogs();
		model.addAttribute("all_blog", allBlogs);
		return AppUtils.INDEX;
	}
	@GetMapping("/contact")  // Define the URL path for the home page
    public String contactus(){
        return "contact";  // This should match the name of your home.html template
    }
	@GetMapping("/about")  // Define the URL path for the home page
    public String aboutus(){
        return "about";  // This should match the name of your home.html template
    }
	
	@GetMapping(value = "/search")
	public String searchBlog(@RequestParam String keyword, Model model) {
		List<BlogsDataResp> allBlogs = blogsServices.searchBlogs(keyword);
		System.out.println("All Blogs"+allBlogs.size());
		model.addAttribute("all_blog", allBlogs);
		return AppUtils.INDEX_TABLE;
	}
	
	@GetMapping(value="/adminD")  // Define the URL path for the home page
    public String adminDashboard() {
		return "adminDashboard";// This should match the name of your home.html template
    }
}
