package com.ag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniProject3BlogAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniProject3BlogAppApplication.class, args);
	}

}
